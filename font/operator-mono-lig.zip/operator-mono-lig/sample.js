// this is a comment
const func = (a, b, c, d, e, f, s, n) => {
    if (a++ && b-- || c >= d || e <= f) {      
    }
    if (s === 'string' && n !== 999) {
    }
    if (a == b && c != d)
    
    a <- b <-- c <== d

    a <| b |> c -> d ==> e 
    
  }
  <!-- test -->

  // italic ligatures
  // != == >= <= -> => ==>
  // === !== && || ++ --
  // a <- b <-- c <== d
  // a <| b |> c -> d ==> e 
  